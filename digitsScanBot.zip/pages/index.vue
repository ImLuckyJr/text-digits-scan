<template>
	<div class='wrapper'>
		<MyCanvas style="width: 100%; height: 600px;">
			<MyBox v-for="(obj, index) of chartValues" :key='index'
			       :x1="((index / chartValues.length) * 100)"
			       :x2="((index / chartValues.length) * 100) + (100 / chartValues.length)"
			       :y1="100"
			       :y2="100 - obj.val"
			       :color="obj.color"
			       :value="obj.val">
			</MyBox>
		</MyCanvas>
	</div>
</template>

<script>
	import MyCanvas from '../components/Canvas';
	import MyBox from '../components/MyBox';

	export default {
		components: {
			MyCanvas,
			MyBox
		},
		data() {
			return {
				chartValues: [
					{ val: 24, color: 'red' },
					{ val: 32, color: '#0f0' },
					{ val: 66, color: 'rebeccapurple' },
					{ val: 1, color: 'green' },
					{ val: 28, color: 'blue' },
					{ val: 60, color: 'rgba(150, 100, 0, 0.2)' }
				],
				test: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAFJklEQVR4Xu3VsRGAQAwEMei/6KcBINj0RO7A8u9wn3PO5SNA4FXgFoiXQeBbQCBeB4EfAYF4HgQE4g0QaAL+IM3N1IiAQEYObc0mIJDmZmpEQCAjh7ZmExBIczM1IiCQkUNbswkIpLmZGhEQyMihrdkEBNLcTI0ICGTk0NZsAgJpbqZGBAQycmhrNgGBNDdTIwICGTm0NZuAQJqbqREBgYwc2ppNQCDNzdSIgEBGDm3NJiCQ5mZqREAgI4e2ZhMQSHMzNSIgkJFDW7MJCKS5mRoREMjIoa3ZBATS3EyNCAhk5NDWbAICaW6mRgQEMnJoazYBgTQ3UyMCAhk5tDWbgECam6kRAYGMHNqaTUAgzc3UiIBARg5tzSYgkOZmakRAICOHtmYTEEhzMzUiIJCRQ1uzCQikuZkaERDIyKGt2QQE0txMjQgIZOTQ1mwCAmlupkYEBDJyaGs2AYE0N1MjAgIZObQ1m4BAmpupEQGBjBzamk1AIM3N1IiAQEYObc0mIJDmZmpEQCAjh7ZmExBIczM1IiCQkUNbswkIpLmZGhEQyMihrdkEBNLcTI0ICGTk0NZsAgJpbqZGBAQycmhrNgGBNDdTIwICGTm0NZuAQJqbqREBgYwc2ppNQCDNzdSIgEBGDm3NJiCQ5mZqREAgI4e2ZhMQSHMzNSIgkJFDW7MJCKS5mRoREMjIoa3ZBATS3EyNCAhk5NDWbAICaW6mRgQEMnJoazYBgTQ3UyMCAhk5tDWbgECam6kRAYGMHNqaTUAgzc3UiIBARg5tzSYgkOZmakRAICOHtmYTEEhzMzUiIJCRQ1uzCQikuZkaERDIyKGt2QQE0txMjQgIZOTQ1mwCAmlupkYEBDJyaGs2AYE0N1MjAgIZObQ1m4BAmpupEQGBjBzamk1AIM3N1IiAQEYObc0mIJDmZmpEQCAjh7ZmExBIczM1IiCQkUNbswkIpLmZGhEQyMihrdkEBNLcTI0ICGTk0NZsAgJpbqZGBAQycmhrNgGBNDdTIwICGTm0NZuAQJqbqREBgYwc2ppNQCDNzdSIgEBGDm3NJiCQ5mZqREAgI4e2ZhMQSHMzNSIgkJFDW7MJCKS5mRoREMjIoa3ZBATS3EyNCAhk5NDWbAICaW6mRgQEMnJoazYBgTQ3UyMCAhk5tDWbgECam6kRAYGMHNqaTUAgzc3UiIBARg5tzSYgkOZmakRAICOHtmYTEEhzMzUiIJCRQ1uzCQikuZkaERDIyKGt2QQE0txMjQgIZOTQ1mwCAmlupkYEBDJyaGs2AYE0N1MjAgIZObQ1m4BAmpupEQGBjBzamk1AIM3N1IiAQEYObc0mIJDmZmpEQCAjh7ZmExBIczM1IiCQkUNbswkIpLmZGhEQyMihrdkEBNLcTI0ICGTk0NZsAgJpbqZGBAQycmhrNgGBNDdTIwICGTm0NZuAQJqbqREBgYwc2ppNQCDNzdSIgEBGDm3NJiCQ5mZqREAgI4e2ZhMQSHMzNSIgkJFDW7MJCKS5mRoREMjIoa3ZBATS3EyNCAhk5NDWbAICaW6mRgQEMnJoazYBgTQ3UyMCAhk5tDWbgECam6kRAYGMHNqaTUAgzc3UiIBARg5tzSYgkOZmakRAICOHtmYTEEhzMzUiIJCRQ1uzCQikuZkaERDIyKGt2QQE0txMjQgIZOTQ1mwCAmlupkYEBDJyaGs2AYE0N1MjAgIZObQ1m4BAmpupEQGBjBzamk1AIM3N1IiAQEYObc0mIJDmZmpE4AEkfR3WLjIGnQAAAABJRU5ErkJggg==',
			};
		},
		created() {
			this.$axios.get('qwerr')
				.then((response) => {
					console.log(response);
				})
				.catch((error) => {
					console.log(error.response);
				});
			// this.$axios.post('/predict', { data: this.test })
			// 	.then((response) => {
			// 		console.log(response);
			// 	})
			// 	.catch((error) => {
			// 		console.log(error);
			// 	});
		},
		// Randomly selects a value to randomly increment or decrement every 16 ms.
		// Not really important, just demonstrates that reactivity still works.
		mounted() {
			let dir = 1;
			let selectedVal = Math.floor(Math.random() * this.chartValues.length);

			setInterval(() => {
				if (Math.random() > 0.995) dir *= -1;
				if (Math.random() > 0.99) selectedVal = Math.floor(Math.random() * this.chartValues.length);

				this.chartValues[selectedVal].val = Math.min(Math.max(this.chartValues[selectedVal].val + dir * 0.5, 0), 100);
			}, 16);
		}
	};
</script>

<style lang='scss'>
	.wrapper {
		width: 100% !important;
		height: 100% !important;
		position: relative;
		
		#canvas {
			width: 100% !important;
			height: 99% !important;
		}
	}
</style>
