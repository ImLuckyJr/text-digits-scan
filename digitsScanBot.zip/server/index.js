require('dotenv').config();
const { Nuxt, Builder } = require('nuxt');
const fastify = require('fastify')({
	logger: true
});

// Import and Set Nuxt.js options
const config = require('../nuxt.config.js');
config.dev = process.env.NODE_ENV !== 'production';

async function start() {
	// Instantiate nuxt.js
	const nuxt = new Nuxt(config);

	console.log(process.env.HOST);
	console.log(process.env.PORT);

	const {
		host = process.env.HOST || '127.0.0.1',
		port = process.env.PORT || 3000
	} = nuxt.options.server;

	// Build only in dev mode
	if (config.dev) {
		const builder = new Builder(nuxt);
		await builder.build();
	} else {
		await nuxt.ready();
	}

	fastify.use(nuxt.render);
	fastify.use(require('cors')());
	// fastify.use(require('dns-prefetch-control')());
	// fastify.use(require('frameguard')());
	// fastify.use(require('hide-powered-by')());
	// fastify.use(require('hsts')());
	// fastify.use(require('ienoopen')());
	// fastify.use(require('x-xss-protection')());

	// Declare a route
	fastify.get('/qwerr', function (request, reply) {
		fastify.log.debug('testing route');
		reply.send({ hello: 'world' });
	});

	fastify.route({
		method: 'GET',
		url:    '/predict',
		schema: {
			body: {
				type:       'object',
				properties: {
					data: { type: 'string' }
				},
				required:   [ 'data' ]
			}
		},
		async handler(request, reply) {
			console.log(request);
			reply
				.code(200)
				.header('Content-Type', 'application/json; charset=utf-8')
				.send({ hello: 'world' });

			// const { spawn } = require('child_process');
			// const pyProg = spawn('python', ["../python/main.py", request.body.data]);
			//
			// console.log(request.body.data);
			// fastify.log.debug(request.body.data);
			//
			// pyProg.stdout.on('data', function(data) {
			//     console.log('script after calling python script');
			//     console.log(data);
			//     console.log(data.toString());
			//     fastify.log.debug('script after calling python script');
			//     fastify.log.debug(data);
			//     fastify.log.debug(data.toString());
			//
			//     reply.code(200);
			//     reply.send({ message: 'OK', statusCode: 200 });
			// });
		}
	});

	fastify.listen(port, host, (err, address) => {
		if (err) {
			fastify.log.error(err);
			process.exit(1);
		}
	});

	// fastify.register(require('fastify-swagger'), {
	// 	routePrefix: '/documentation',
	// 	swagger: {
	// 		info: {
	// 			title: 'Test swagger',
	// 			description: 'testing the fastify swagger api',
	// 			version: '0.1.0'
	// 		},
	// 		externalDocs: {
	// 			url: 'https://swagger.io',
	// 			description: 'Find more info here'
	// 		},
	// 		host: 'localhost',
	// 		schemes: ['http'],
	// 		consumes: ['application/json'],
	// 		produces: ['application/json'],
	// 		tags: [
	// 			{ name: 'user', description: 'User related end-points' },
	// 			{ name: 'code', description: 'Code related end-points' }
	// 		],
	// 		securityDefinitions: {
	// 			apiKey: {
	// 				type: 'apiKey',
	// 				name: 'apiKey',
	// 				in: 'header'
	// 			}
	// 		}
	// 	}
	// })
}

start();
